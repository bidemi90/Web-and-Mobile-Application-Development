
// Javascript Program to Check if a number is Positive, Negative, or Zero
const prompt = require('prompt-sync')(); //this line is essential
console.log("starting");
const name = prompt("enter your name: ");
console.log(`hello ,${name}`);
// program to check if the number is positive, negative or zero
const number = parseFloat(prompt("enter a number: "));

//check if number is greater than 0
if (number > 0) {
  console.log("the number is positive");
}
//check if number is 0
else if (number == 0) {
  console.log("the number is zero");
}
// if number is less than 0
else if (number < 0) {
  console.log("the number is negative");
}
