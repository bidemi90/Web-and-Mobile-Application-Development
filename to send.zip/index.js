console.log("this is my frst programe");
console.log("well come john your month salary is 500000$");
// JavaScript program that performs basic arithmetic operations—addition, subtraction, multiplication, and division—on two numbers
const num1 = 5;
const num2 = 3;
// addition of two numbers
const sum = num1 + num2;
console.log("the sum of " + num1 + " and " + num2 + " numbers is " + sum);

// subtraction of two numbers
const sub = num1 - num2;
console.log(
  "the subtraction of " + num1 + " and " + num2 + " numbers is " + sub
);

// multiplication of two numbers
const mul = num1 * num2;
console.log(
  "the multiplication of " + num1 + " and " + num2 + " numbers is " + mul
);

// division of two numbers
const div = num1 / num2;
console.log("the division of " + num1 + " and " + num2 + " numbers is " + div);
